#!/bin/bash
$PYTHON ./setup.py install --record=record.txt
